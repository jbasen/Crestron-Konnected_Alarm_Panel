﻿using System.Reflection;

[assembly: AssemblyTitle("Konnected")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Konnected")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2020")]
[assembly: AssemblyVersion("1.0.0.*")]

