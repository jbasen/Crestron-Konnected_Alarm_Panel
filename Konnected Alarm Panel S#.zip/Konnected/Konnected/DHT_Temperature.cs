﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;

namespace Konnected_Integration
{
    public class DHT_Temperature 
    {  
		#region Declarations
		public string id { get; set; }
		public double value { get; set; }
		public string state { get; set; }
		#endregion Declarations

		//****************************************************************************************
		// 
		//  Parse	-   
		// 
		//****************************************************************************************
		public static DHT_Temperature Parse(string JSON)
		{
			try
			{
				string s = Konnected.Parse_Data_Substring(JSON, "", "\"value\":", ",");
				s = s.ToLower();
				if (s != "null")
				{
					DHT_Temperature Status = JsonConvert.DeserializeObject<DHT_Temperature>(JSON);
					return Status;
				}
				else
				{
					return null;
				}
			}
			catch (Exception e)
			{
				string err = "Error Parsing JSON: " + e;
				CrestronConsole.PrintLine("Konnected - DHT_Temperature - Parse - " + err);
				Crestron.SimplSharp.ErrorLog.Error("Konnected - DHT_Temperature - Parse - " + err + "\n");
				return null;
			}
		}
    }
}