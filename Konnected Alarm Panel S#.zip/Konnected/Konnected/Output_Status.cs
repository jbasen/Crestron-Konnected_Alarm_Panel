﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;

namespace Konnected_Integration
{
	public class Output_Status
	{
		#region Declarations
		public string id { get; set; }
		public bool value { get; set; }
		public string state { get; set; }
		#endregion Declarations

		//****************************************************************************************
		// 
		//  Parse	-   
		// 
		//****************************************************************************************
		public static Output_Status Parse(string JSON)
		{
			try
			{
				string s = Konnected.Parse_Data_Substring(JSON, "", "\"value\":", ",");
				s = s.ToLower();
				if (s != "null")
				{
					Output_Status Status = JsonConvert.DeserializeObject<Output_Status>(JSON);
					return Status;
				}
				else
				{
					return null;
				}
			}
			catch (Exception e)
			{
				string err = "Error Parsing JSON: " + e;
				CrestronConsole.PrintLine("Konnected - Output_Status - Parse - " + err);
				Crestron.SimplSharp.ErrorLog.Error("Konnected - Output_Status - Parse - " + err + "\n");
				return null;
			}
		}

	}
}