﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Http;
using System.Collections.Generic;
using Newtonsoft.Json;
using Crestron.SimplSharp.CrestronIO;
using System.Threading;


namespace Konnected_Integration
{
	#region Classes
	//Event Classes
	public class SerialChangeEventArgs : EventArgs
	{
		public short Type { get; set; }
		public string Msg { get; set; }
		public string MAC_Address { get; set; }
		public short Zone { get; set; }
		public short State  { get; set; }
		public short Temperature  { get; set; }
		public short Humidity  { get; set; }

		public SerialChangeEventArgs()
		{
		}

		public SerialChangeEventArgs(short Type, string Msg, string MAC_Address, short Zone, short State, short Temperature, short Humidity)
		{
			#region Set Class Data Elements from Parameters
			this.Type = Type;
			this.Msg = Msg;
			this.MAC_Address = MAC_Address;
			this.Zone = Zone;
			this.State = State;
			this.Temperature = Temperature;
			this.Humidity = Humidity;
			#endregion
		}
	}

	public static class SignalChangeEvents
	{
		public static event SerialChangedEventHandler onSerialValueChange;

		public static void SerialValueChange(short Type, string Msg, string MAC_Address, short Zone, short State, short Temperature, short Humidity)
		{
			SignalChangeEvents.onSerialValueChange(new SerialChangeEventArgs(Type, Msg, MAC_Address, Zone, State, Temperature, Humidity));
		}
	}

	//Classes for Board List
	class Zone
	{
		public short id;
		public string name;

		//Constructors
		public Zone()
		{
		}

		public Zone(short id, string name)
		{
			this.id = id;
			this.name = name;
		}
	}

	class Board
	{
		public string MAC_Address;
		public int Zone_Count;
		public string IP_Address;
		public short Port;
		public List<Zone> Zones = new List<Zone>();
		public HttpClient client;
		public HttpClientRequest request;
		public HttpClientResponse response;

		//Constructors
		public Board()
		{
		}

		public Board(string MAC_Address, short Zone_Count, string IP_Address, short Port, string Zone_Name_1, string Zone_Name_2, 
			string Zone_Name_3, string Zone_Name_4, string Zone_Name_5, string Zone_Name_6, string Zone_Name_7, string Zone_Name_8,
			string Zone_Name_9, string Zone_Name_10, string Zone_Name_11, string Zone_Name_12, string Zone_Name_13, string Zone_Name_14, 
			string Zone_Name_15)
		{
			this.MAC_Address = MAC_Address;
			this.Zone_Count = Zone_Count;
			this.IP_Address = IP_Address;
			this.Port = Port;

			Zone Zone_Data_1 = new Zone(1, Zone_Name_1);
			Zones.Add(Zone_Data_1);
			Zone Zone_Data_2 = new Zone(2, Zone_Name_2);
			Zones.Add(Zone_Data_2);
			Zone Zone_Data_3 = new Zone(3, Zone_Name_3);
			Zones.Add(Zone_Data_3);
			Zone Zone_Data_4 = new Zone(4, Zone_Name_4);
			Zones.Add(Zone_Data_4);
			Zone Zone_Data_5 = new Zone(5, Zone_Name_5);
			Zones.Add(Zone_Data_5);
			Zone Zone_Data_6 = new Zone(6, Zone_Name_6);
			Zones.Add(Zone_Data_6);
			Zone Zone_Data_7 = new Zone(7, Zone_Name_7);
			Zones.Add(Zone_Data_7);
			Zone Zone_Data_8 = new Zone(8, Zone_Name_8);
			Zones.Add(Zone_Data_8);
			Zone Zone_Data_9 = new Zone(9, Zone_Name_9);
			Zones.Add(Zone_Data_9);
			Zone Zone_Data_10 = new Zone(10, Zone_Name_10);
			Zones.Add(Zone_Data_10);
			Zone Zone_Data_11 = new Zone(11, Zone_Name_11);
			Zones.Add(Zone_Data_11);
			Zone Zone_Data_12 = new Zone(12, Zone_Name_12);
			Zones.Add(Zone_Data_12);
			Zone Zone_Data_13 = new Zone(13, Zone_Name_13);
			Zones.Add(Zone_Data_13);
			Zone Zone_Data_14 = new Zone(14, Zone_Name_14);
			Zones.Add(Zone_Data_14);
			Zone Zone_Data_15 = new Zone(15, Zone_Name_15);
			Zones.Add(Zone_Data_15);
		}
	}
	#endregion

	#region Delegates
	public delegate void SerialChangedEventHandler(SerialChangeEventArgs e);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Konnected
	{
		#region Declarations
		private static Debug_Options Debug;
		private static string Processor_IP_Address;
		private static string Processor_Port;
		private static List<Board> Boards;

		private const short Type_Sensor_Update = 1;
		private const short Type_Comm_Error = 2;

		private const short Sensor_Type_Binary = 1;
		private const short Sensor_Type_DHT = 2;
		private const short Sensor_Type_DS18B20 = 3;

		private const short Config_Normally_Open = 1;
		private const short Config_Normally_Closed = 2;
		private const short Config_DHT = 3;
		private const short Config_DS18B20 = 4;
		private const short Config_Actuator = 5;
		#endregion

		//****************************************************************************************
		// 
		//  Konnected	-	Default Constructor
		// 
		//****************************************************************************************
		public Konnected()
		{
		}

		//****************************************************************************************
		// 
		//  Konnected	-	Default Destructor
		// 
		//****************************************************************************************
		~Konnected()
		{
			foreach (Board b in Boards)
			{
				b.client.Dispose();
				b.response.Dispose();
			}
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialize system by setting up globals
		//					and setting up http server for update
		//					messages from Konnected.  Called by
		//					Comm Module
		// 
		//****************************************************************************************
		public short Initialize(string Processor_IP_Address, string Processor_Port, short Debug)
		{
			#region Save Parameters in Globals
			Konnected.Processor_IP_Address = Processor_IP_Address;
			Konnected.Processor_Port = Processor_Port;
			Set_Debug_Message_Output(Debug);
			#endregion

			#region Create list for each board
			try
			{
				Boards = new List<Board>();
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Konnected - Initialize - Can't create board list: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Konnected - Initialize - Can't create board list: " + e + "\n");
				return 0;
			}
			#endregion

			Debug_Message("Initialize", "Processor_IP_Address = " + Processor_IP_Address + ", Processor_Port = " + Processor_Port);
			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Initialize_Board	-	Initialize Board Settings.
		// 
		//****************************************************************************************
		public void Initialize_Board(string MAC_Address, short Zone_Count, string IP_Address, short Port, string Zone_1_Name, string Zone_2_Name, 
			string Zone_3_Name, string Zone_4_Name, string Zone_5_Name, string Zone_6_Name, string Zone_7_Name, string Zone_8_Name, string Zone_9_Name, 
			string Zone_10_Name, string Zone_11_Name, string Zone_12_Name, string Zone_13_Name, string Zone_14_Name, string Zone_15_Name)
		{

			Debug_Message("Initialize_Board", "MAC_Address = " + MAC_Address + ", Zone_Count = " + Zone_Count + ", IP_Address = " + IP_Address + ", Port = " + Port);

			#region Parameter Checking
			//Check for duplicate
			if (Boards.Exists(x => x.MAC_Address == MAC_Address))
			{
				//Duplicate Found
				Debug_Message("Board_Initialize", "Duplicate Board Registration - MAC_Address = " + MAC_Address);
				return;
			}
			#endregion

			#region Add Device to List
			//Add Device to list of Devices using device type enum
			try
			{
				Board Board_Data = new Board(MAC_Address, Zone_Count, IP_Address, Port, Zone_1_Name, Zone_2_Name, Zone_3_Name, 
					Zone_4_Name, Zone_5_Name, Zone_6_Name, Zone_7_Name, Zone_8_Name, Zone_9_Name, Zone_10_Name, Zone_11_Name, 
					Zone_12_Name, Zone_13_Name, Zone_14_Name, Zone_15_Name);
				Boards.Add(Board_Data);
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Konnected - Board_Initialize - Can't Register Board: MAC_Address = " + MAC_Address + ", Error = " + e);
				Crestron.SimplSharp.ErrorLog.Error("Konnected - Board_Initialize - Can't Register Board: MAC_Address = " + MAC_Address + ", Error = " + e);
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Binary_Zone_State	-	Retrieves the state of a selected zone
		// 
		//****************************************************************************************
		public short Get_Binary_Zone_State(string MAC_Address, short Zone)
		{
			HttpClient client = null;

			Debug_Message("Get_Binary_Zone_State", "MAC_Address = " + MAC_Address + ", Zone = " + Zone);

			#region Get Board Info
			Board b = Boards.Find(x => x.MAC_Address == MAC_Address);
			Zone z = b.Zones.Find(x => x.id == Zone);
			#endregion

			#region Create url
			string url = "http://" + b.IP_Address + ":" + b.Port + "/binary_sensor/" + z.name + "/";
			Debug_Message("Get_Binary_Zone_State", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Konnected - Get_Binary_Zone_State - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return -999;
				}
				else
				{
					Debug_Message("Get_Binary_Zone_State", "Success - response.ContentString = " + response.ContentString);
					Zone_Status zs = Zone_Status.Parse(response.ContentString);
					if (zs != null)
					{
						Debug_Message("Get_Binary_Zone_State", "Binary Zone Parsed - value = " + zs.value);
						if (zs.value == true)
						{
							return 1;
						}
						else
						{
							return 0;
						}
					}
					else
					{
						Debug_Message("Get_Binary_Zone_State", "Null Sensor Value");
						return Convert.ToInt16(-999);
					}
				}
			}
			catch (Exception e)
			{
				string err = "Konnected - Get_Binary_Zone_State - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return -999;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Output_State	-	Retrieves the state of a selected output
		// 
		//****************************************************************************************
		public short Get_Output_State(string MAC_Address, short Output)
		{
			HttpClient client = null;

			Debug_Message("Get_Output_State", "MAC_Address = " + MAC_Address + ", Output = " + Output);

			#region Get Board Info
			Board b = Boards.Find(x => x.MAC_Address == MAC_Address);
			Zone z = b.Zones.Find(x => x.id == Output);
			#endregion

			#region Create url
			string url = "http://" + b.IP_Address + ":" + b.Port + "/switch/" + z.name + "/";
			Debug_Message("Get_Output_State", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Konnected - Get_Output_State - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return -999;
				}
				else
				{
					Debug_Message("Get_Output_State", "Success - response.ContentString = " + response.ContentString);
					Output_Status os = Output_Status.Parse(response.ContentString);
					if (os != null)
					{
						Debug_Message("Get_Output_State", "Zone Output Parsed - value = " + os.value);
						if (os.value == true)
						{
							return 1;
						}
						else
						{
							return 0;
						}
					}
					else
					{
						Debug_Message("Get_Output_State", "Null Sensor Value");
						return Convert.ToInt16(-999);
					}
				}
			}
			catch (Exception e)
			{
				string err = "Konnected - Get_Output_State - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return -999;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_DHT_Temperature	-	Retrieves the temperature from a DHT Sensor
		// 
		//****************************************************************************************
		public short Get_DHT_Temperature(string MAC_Address, short Output)
		{
			HttpClient client = null;

			Debug_Message("Get_DHT_Temperature", "MAC_Address = " + MAC_Address + ", Output = " + Output);

			#region Get Board Info
			Board b = Boards.Find(x => x.MAC_Address == MAC_Address);
			Zone z = b.Zones.Find(x => x.id == Output);
			#endregion

			#region Create url
			string url = "http://" + b.IP_Address + ":" + b.Port + "/sensor/" + z.name + "_temperature/";
			Debug_Message("Get_DHT_Temperature", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Konnected - Get_DHT_Temperature - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return -999;
				}
				else
				{
					Debug_Message("Get_DHT_Temperature", "Success - response.ContentString = " + response.ContentString);
					DHT_Temperature os = DHT_Temperature.Parse(response.ContentString);
					if (os != null)
					{
						Debug_Message("Get_DHT_Temperature", "Zone Output Parsed - value = " + os.value);
						short s = Convert.ToInt16(Math.Round(os.value, 0));//Round and convert to short
						return s;
					}
					else
					{
						Debug_Message("Get_DHT_Temperature", "Null Sensor Value");
						return Convert.ToInt16(-999);
					}
				}
			}
			catch (Exception e)
			{
				string err = "Konnected - Get_DHT_Temperature - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return -999;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_DHT_Humidity	-	Retrieves the humidity from a DHT Sensor
		// 
		//****************************************************************************************
		public short Get_DHT_Humidity(string MAC_Address, short Output)
		{
			HttpClient client = null;

			Debug_Message("Get_DHT_Humidity", "MAC_Address = " + MAC_Address + ", Output = " + Output);

			#region Get Board Info
			Board b = Boards.Find(x => x.MAC_Address == MAC_Address);
			Zone z = b.Zones.Find(x => x.id == Output);
			#endregion

			#region Create url
			string url = "http://" + b.IP_Address + ":" + b.Port + "/sensor/" + z.name + "_humidity/";
			Debug_Message("Get_DHT_Humidity", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Konnected - Get_DHT_Humidity - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return -999;
				}
				else
				{
					Debug_Message("Get_DHT_Humidity", "Success - response.ContentString = " + response.ContentString);
					DHT_Temperature os = DHT_Temperature.Parse(response.ContentString);
					if (os != null)
					{
						Debug_Message("Get_DHT_Humidity", "Zone Output Parsed - value = " + os.value);
						short s = Convert.ToInt16(Math.Round(os.value, 0));//Round and convert to short
						return s;
					}
					else
					{
						Debug_Message("Get_DHT_Humidity", "Null Sensor Value");
						return Convert.ToInt16(-999);
					}
				}
			}
			catch (Exception e)
			{
				string err = "Konnected - Get_DHT_Humidity - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return -999;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Board_Output	-	Sends a command to turn on/off an output to
		//							a Konnected board
		// 
		//****************************************************************************************
		public void Set_Board_Output(string MAC_Address, short Zone, short State)
		{
			HttpClient client = null;

			Debug_Message("Set_Board_Output", "MAC_Address = " + MAC_Address + ", Zone = " + Zone + ", State = " + State);

			#region Get Board Info
			Board b = Boards.Find(x => x.MAC_Address == MAC_Address);
			Zone z = b.Zones.Find(x => x.id == Zone);
			#endregion

			#region Create url
			string url = "http://" + b.IP_Address + ":" + b.Port + "/switch/" + z.name + "/";
			if (State == 1)
			{
				url += "turn_on";
			}
			else
			{
				url += "turn_off";
			}
			Debug_Message("Set_Board_Output", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Post;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Konnected - Set_Board_Output - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}
				else
				{
					Debug_Message("Set_Board_Output", "Success");
				}
			}
			catch (Exception e)
			{
				string err = "Konnected - Set_Board_Output - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  SSE_Init	-	Start server side events receiver
		// 
		//****************************************************************************************
		public void SSE_Init(string MAC_Address)
		{
			Debug_Message("SSE_Init", "Starting - MAC_Address = " + MAC_Address);

			#region Get Board Info
			Board b = Boards.Find(x => x.MAC_Address == MAC_Address);
			#endregion

			#region Create URL
			string url = "http://" + b.IP_Address + "/events";
			Debug_Message("SSE_Init", "url = " + url);
			#endregion

			#region Client Connection
			b.client = new HttpClient();
			b.request = new HttpClientRequest();
			b.request.RequestType = RequestType.Get;
			b.request.Url.Parse(url);
			b.request.KeepAlive = true;
			b.request.Header.SetHeaderValue("Accept", "text/event-stream");
			b.request.Header.SetHeaderValue("Accept-Encoding", "gzip,deflate");
			b.request.Header.SetHeaderValue("Accept-Language", "en-US,en;q=0.9");

			//Get Response
			b.response = b.client.Dispatch(b.request);
			if (b.response.Code < 200 || b.response.Code >= 300)
			{
				// server threw a error.
				string err = "Konnected - SSE_Init - http response code: " + b.response.Code;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion
			
			CrestronInvoke.BeginInvoke(parameter => { SSE_Thread(b); });
		}

		//****************************************************************************************
		// 
		//  SSE_Thread	-	Separate thread for parsing SSE data and passing it back
		// 
		//****************************************************************************************
		private void SSE_Thread(Board b)
		{
			string s, t;
			double d;
			short Temperature = -999;
			short Humidity = -999;
			short state;
			int i;

			Debug_Message("SSE_Thread", "Started - Board = " + b.MAC_Address);

			while (true)
			{
				s = b.response.DataConnection.ReadLine();

				//Eliminate Unwanted Messages
				if ((string.IsNullOrEmpty(s) == false) && (s.StartsWith("data:") == true) && (s.Contains("\"title\":") == false)
					 && (s.Contains("\"id\":\"sensor-uptime\"") == false) && (s.Contains("\"id\":\"sensor-heap_free\"") == false)
					 && (s.Contains("\"id\":\"button-restart\"") == false) && (s.Contains("\"id\":\"text_sensor") == false)
					 && (s.Contains("\"id\":\"sensor-uptime\"") == false) && (s.Contains("\"id\":\"sensor-wifi_signal__\"") == false)
					 && (s.Contains("\"id\":\"sensor-wifi_signal_rssi\"") == false) && (s.Contains("") == false))
				{
					s = "{" + Parse_Data_Substring(s, "", "{", "}") + "}"; //isolate JSON
					if (s != "{}")
					{
						try
						{
							#region Parse
							Debug_Message("SSE_Thread", "s = " + s);
							SSEvent e = JsonConvert.DeserializeObject<SSEvent>(s);

							#region Make sure e.name isn't null
							if (string.IsNullOrEmpty(e.name) == true)
							{
								Debug_Message("SSE_Thread", "e.id = " + e.id);
								e.id += "*"; //add terminating character that would be illegal in esphome name

								//extract name from id
								if (e.id.Contains("_humidity*"))
								{
									e.name = Parse_Data_Substring(e.id, "", "-", "_humidity*");
								}
								else if (e.id.Contains("_temperature*"))
								{
									e.name = Parse_Data_Substring(e.id, "", "-", "_temperature*");
								}
								else
								{
									e.name = Parse_Data_Substring(e.id, "", "-", "*");
								}
							}
							#endregion
							
							Debug_Message("SSE_Thread", "name = " + e.name + ", state = " + e.state);
							if ((e.state != "ON") && (e.state != "OFF") && (e.state != "NA"))
							{
								i = e.state.IndexOf(" ");
								t = e.state.Substring(0, i);
								if (e.id.Contains("humidity"))
								{
									d = double.Parse(t);
									d = Math.Round(d, 0);
									Humidity = Convert.ToInt16(d);
									e.state = "HUMIDITY";
									//remove string appended to name
									if (e.name.EndsWith(" Humidity"))
									{
										e.name = e.name.Substring(0, e.name.LastIndexOf(" Humidity"));
									}
								}
								else
								{
									d = double.Parse(t);
									d = Math.Round(d, 0);
									Temperature = Convert.ToInt16(d);
									e.state = "TEMPERATURE";
									//remove string appended to name
									if (e.name.EndsWith(" Temperature"))
									{
										e.name = e.name.Substring(0, e.name.LastIndexOf(" Temperature"));
									}
								}
							}
							Zone z = b.Zones.Find(x => x.name == e.name);
							Debug_Message("SSE_Thread", "name = " + e.name + ", id = " + z.id + ", state = " + e.state + ", Humidity = " + Humidity + ", Temperature = " + Temperature);
							#endregion

							#region State
							if ((e.state == "ON") || (e.state == "TRUE"))
							{
								state = 1;
							}
							else if ((e.state == "OFF") || (e.state == "FALSE"))
							{
								state = 0;
							}
							else if ((e.state == "TEMPERATURE") || (e.state == "HUMIDITY") || (e.state == "NA"))
							{
								state = -1;
							}
							else
							{
								Debug_Message("SSE_Thread", "UNHANDLED VALUE - e.state = " + e.state);
								state = -1;
							}
							#endregion

							//Pass Back to S+
							SignalChangeEvents.SerialValueChange(Type_Sensor_Update, "", b.MAC_Address, z.id, state, Temperature, Humidity);

						}
						catch (Exception ex)
						{
							CrestronConsole.PrintLine("Konnected - SSE_Thread - " + ex.Message);
						}
					}
				}
			}
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		public static string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//Reporting of not finding section or string as an error eliminted because 
			//there are too many situations where the code has to accomodate the fact
			//that Konnected will send back very different messages depending on exactly
			//what setting was changed on a device.  Thermostat is the prime example

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Konnected - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Konnected - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Konnected - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Konnected - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Konnected - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Konnected - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Konnected.Debug = Debug_Options.None;
					break;

				case 1:
					Konnected.Debug = Debug_Options.Console;
					break;

				case 2:
					Konnected.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Konnected.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private static void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Konnected - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Konnected - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}

		//****************************************************************************************
		// 
		//  Report_Communications_Error	-	Sends a communications error information
		//									to the receiver module for reporting
		// 
		//****************************************************************************************
		private void Report_Communications_Error(string msg)
		{
			SignalChangeEvents.SerialValueChange(Type_Comm_Error, msg, "", 0, 0, 0, 0);
		}

	}

	public class SSEvent
	{
		public string id { get; set; }
		public string name { get; set; }
		public string state { get; set; }
	}
}
